﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.txtTotal = New System.Windows.Forms.TextBox
        Me.nudOne = New System.Windows.Forms.NumericUpDown
        Me.nudTwo = New System.Windows.Forms.NumericUpDown
        Me.nudEleven = New System.Windows.Forms.NumericUpDown
        Me.nudNine = New System.Windows.Forms.NumericUpDown
        Me.nudSeven = New System.Windows.Forms.NumericUpDown
        Me.nudFive = New System.Windows.Forms.NumericUpDown
        Me.nudThree = New System.Windows.Forms.NumericUpDown
        Me.nudEight = New System.Windows.Forms.NumericUpDown
        Me.nudTen = New System.Windows.Forms.NumericUpDown
        Me.nudSix = New System.Windows.Forms.NumericUpDown
        Me.nudFour = New System.Windows.Forms.NumericUpDown
        Me.nudTwelve = New System.Windows.Forms.NumericUpDown
        Me.txtTotal2 = New System.Windows.Forms.TextBox
        Me.txtTotal5 = New System.Windows.Forms.TextBox
        Me.txtTotal4 = New System.Windows.Forms.TextBox
        Me.txtTotal3 = New System.Windows.Forms.TextBox
        Me.txtTotal6 = New System.Windows.Forms.TextBox
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ContentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.TextBox4 = New System.Windows.Forms.TextBox
        Me.TextBox5 = New System.Windows.Forms.TextBox
        Me.TextBox6 = New System.Windows.Forms.TextBox
        Me.TextBox7 = New System.Windows.Forms.TextBox
        Me.TextBox8 = New System.Windows.Forms.TextBox
        Me.TextBox9 = New System.Windows.Forms.TextBox
        Me.TextBox10 = New System.Windows.Forms.TextBox
        Me.TextBox11 = New System.Windows.Forms.TextBox
        Me.TextBox12 = New System.Windows.Forms.TextBox
        Me.TextBox13 = New System.Windows.Forms.TextBox
        Me.TextBox14 = New System.Windows.Forms.TextBox
        Me.TextBox15 = New System.Windows.Forms.TextBox
        Me.TextBox16 = New System.Windows.Forms.TextBox
        Me.TextBox17 = New System.Windows.Forms.TextBox
        Me.TextBox18 = New System.Windows.Forms.TextBox
        Me.TextBox19 = New System.Windows.Forms.TextBox
        Me.TextBox20 = New System.Windows.Forms.TextBox
        Me.TextBox21 = New System.Windows.Forms.TextBox
        Me.TextBox22 = New System.Windows.Forms.TextBox
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        CType(Me.nudOne, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTwo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudEleven, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudNine, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudSeven, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudFive, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudThree, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudEight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudSix, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudFour, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudTwelve, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 300)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(88, 29)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Calculate"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtTotal
        '
        Me.txtTotal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtTotal.Location = New System.Drawing.Point(260, 59)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(80, 13)
        Me.txtTotal.TabIndex = 3
        '
        'nudOne
        '
        Me.nudOne.Location = New System.Drawing.Point(115, 59)
        Me.nudOne.Name = "nudOne"
        Me.nudOne.ReadOnly = True
        Me.nudOne.Size = New System.Drawing.Size(37, 20)
        Me.nudOne.TabIndex = 4
        Me.nudOne.Value = New Decimal(New Integer() {75, 0, 0, 0})
        '
        'nudTwo
        '
        Me.nudTwo.Location = New System.Drawing.Point(198, 59)
        Me.nudTwo.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.nudTwo.Name = "nudTwo"
        Me.nudTwo.Size = New System.Drawing.Size(37, 20)
        Me.nudTwo.TabIndex = 5
        '
        'nudEleven
        '
        Me.nudEleven.Location = New System.Drawing.Point(115, 244)
        Me.nudEleven.Name = "nudEleven"
        Me.nudEleven.ReadOnly = True
        Me.nudEleven.Size = New System.Drawing.Size(37, 20)
        Me.nudEleven.TabIndex = 6
        Me.nudEleven.Value = New Decimal(New Integer() {94, 0, 0, 0})
        '
        'nudNine
        '
        Me.nudNine.Location = New System.Drawing.Point(115, 203)
        Me.nudNine.Name = "nudNine"
        Me.nudNine.ReadOnly = True
        Me.nudNine.Size = New System.Drawing.Size(37, 20)
        Me.nudNine.TabIndex = 7
        Me.nudNine.Value = New Decimal(New Integer() {85, 0, 0, 0})
        '
        'nudSeven
        '
        Me.nudSeven.Location = New System.Drawing.Point(115, 168)
        Me.nudSeven.Name = "nudSeven"
        Me.nudSeven.ReadOnly = True
        Me.nudSeven.Size = New System.Drawing.Size(37, 20)
        Me.nudSeven.TabIndex = 8
        Me.nudSeven.Value = New Decimal(New Integer() {60, 0, 0, 0})
        '
        'nudFive
        '
        Me.nudFive.Location = New System.Drawing.Point(115, 133)
        Me.nudFive.Name = "nudFive"
        Me.nudFive.ReadOnly = True
        Me.nudFive.Size = New System.Drawing.Size(37, 20)
        Me.nudFive.TabIndex = 9
        Me.nudFive.Value = New Decimal(New Integer() {80, 0, 0, 0})
        '
        'nudThree
        '
        Me.nudThree.Location = New System.Drawing.Point(115, 97)
        Me.nudThree.Name = "nudThree"
        Me.nudThree.ReadOnly = True
        Me.nudThree.Size = New System.Drawing.Size(37, 20)
        Me.nudThree.TabIndex = 10
        Me.nudThree.Value = New Decimal(New Integer() {52, 0, 0, 0})
        '
        'nudEight
        '
        Me.nudEight.Location = New System.Drawing.Point(198, 168)
        Me.nudEight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.nudEight.Name = "nudEight"
        Me.nudEight.Size = New System.Drawing.Size(37, 20)
        Me.nudEight.TabIndex = 11
        '
        'nudTen
        '
        Me.nudTen.Location = New System.Drawing.Point(198, 203)
        Me.nudTen.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.nudTen.Name = "nudTen"
        Me.nudTen.Size = New System.Drawing.Size(37, 20)
        Me.nudTen.TabIndex = 12
        '
        'nudSix
        '
        Me.nudSix.Location = New System.Drawing.Point(198, 133)
        Me.nudSix.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.nudSix.Name = "nudSix"
        Me.nudSix.Size = New System.Drawing.Size(37, 20)
        Me.nudSix.TabIndex = 13
        '
        'nudFour
        '
        Me.nudFour.Location = New System.Drawing.Point(198, 97)
        Me.nudFour.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.nudFour.Name = "nudFour"
        Me.nudFour.Size = New System.Drawing.Size(37, 20)
        Me.nudFour.TabIndex = 14
        '
        'nudTwelve
        '
        Me.nudTwelve.Location = New System.Drawing.Point(198, 244)
        Me.nudTwelve.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.nudTwelve.Name = "nudTwelve"
        Me.nudTwelve.Size = New System.Drawing.Size(37, 20)
        Me.nudTwelve.TabIndex = 15
        '
        'txtTotal2
        '
        Me.txtTotal2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtTotal2.Location = New System.Drawing.Point(260, 97)
        Me.txtTotal2.Name = "txtTotal2"
        Me.txtTotal2.ReadOnly = True
        Me.txtTotal2.Size = New System.Drawing.Size(80, 13)
        Me.txtTotal2.TabIndex = 16
        '
        'txtTotal5
        '
        Me.txtTotal5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtTotal5.Location = New System.Drawing.Point(260, 203)
        Me.txtTotal5.Name = "txtTotal5"
        Me.txtTotal5.ReadOnly = True
        Me.txtTotal5.Size = New System.Drawing.Size(80, 13)
        Me.txtTotal5.TabIndex = 17
        '
        'txtTotal4
        '
        Me.txtTotal4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtTotal4.Location = New System.Drawing.Point(260, 168)
        Me.txtTotal4.Name = "txtTotal4"
        Me.txtTotal4.ReadOnly = True
        Me.txtTotal4.Size = New System.Drawing.Size(80, 13)
        Me.txtTotal4.TabIndex = 18
        '
        'txtTotal3
        '
        Me.txtTotal3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtTotal3.Location = New System.Drawing.Point(260, 133)
        Me.txtTotal3.Name = "txtTotal3"
        Me.txtTotal3.ReadOnly = True
        Me.txtTotal3.Size = New System.Drawing.Size(80, 13)
        Me.txtTotal3.TabIndex = 19
        '
        'txtTotal6
        '
        Me.txtTotal6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtTotal6.Location = New System.Drawing.Point(260, 244)
        Me.txtTotal6.Name = "txtTotal6"
        Me.txtTotal6.ReadOnly = True
        Me.txtTotal6.Size = New System.Drawing.Size(80, 13)
        Me.txtTotal6.TabIndex = 20
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(352, 24)
        Me.MenuStrip1.TabIndex = 21
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(92, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContentsToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'ContentsToolStripMenuItem
        '
        Me.ContentsToolStripMenuItem.Name = "ContentsToolStripMenuItem"
        Me.ContentsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ContentsToolStripMenuItem.Text = "Contents"
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(0, 27)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(72, 15)
        Me.TextBox1.TabIndex = 22
        Me.TextBox1.Text = "Employee"
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(251, 27)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(101, 15)
        Me.TextBox2.TabIndex = 23
        Me.TextBox2.Text = "Weekly Pay"
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(190, 26)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(55, 15)
        Me.TextBox3.TabIndex = 24
        Me.TextBox3.Text = "Hours"
        '
        'TextBox4
        '
        Me.TextBox4.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(94, 27)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(95, 15)
        Me.TextBox4.TabIndex = 25
        Me.TextBox4.Text = "$Rate/Hour"
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox5.Location = New System.Drawing.Point(4, 61)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 13)
        Me.TextBox5.TabIndex = 26
        Me.TextBox5.Text = "Sean Connery"
        '
        'TextBox6
        '
        Me.TextBox6.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox6.Location = New System.Drawing.Point(4, 203)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(100, 13)
        Me.TextBox6.TabIndex = 27
        Me.TextBox6.Text = "Pierce Brosnan"
        '
        'TextBox7
        '
        Me.TextBox7.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox7.Location = New System.Drawing.Point(4, 170)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 13)
        Me.TextBox7.TabIndex = 28
        Me.TextBox7.Text = "Timothy Dalton"
        '
        'TextBox8
        '
        Me.TextBox8.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox8.Location = New System.Drawing.Point(4, 140)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 13)
        Me.TextBox8.TabIndex = 29
        Me.TextBox8.Text = "Roger Moore"
        '
        'TextBox9
        '
        Me.TextBox9.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox9.Location = New System.Drawing.Point(4, 99)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(100, 13)
        Me.TextBox9.TabIndex = 30
        Me.TextBox9.Text = "George Lazenby"
        '
        'TextBox10
        '
        Me.TextBox10.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox10.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox10.Location = New System.Drawing.Point(4, 244)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(100, 13)
        Me.TextBox10.TabIndex = 31
        Me.TextBox10.Text = "Daniel Craig"
        '
        'TextBox11
        '
        Me.TextBox11.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox11.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox11.Location = New System.Drawing.Point(83, 61)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(26, 13)
        Me.TextBox11.TabIndex = 32
        Me.TextBox11.Text = "$"
        Me.TextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox12
        '
        Me.TextBox12.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox12.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox12.Location = New System.Drawing.Point(83, 170)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(26, 13)
        Me.TextBox12.TabIndex = 33
        Me.TextBox12.Text = "$"
        Me.TextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox13
        '
        Me.TextBox13.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox13.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox13.Location = New System.Drawing.Point(83, 140)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(26, 13)
        Me.TextBox13.TabIndex = 34
        Me.TextBox13.Text = "$"
        Me.TextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox14
        '
        Me.TextBox14.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox14.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox14.Location = New System.Drawing.Point(83, 205)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(26, 13)
        Me.TextBox14.TabIndex = 35
        Me.TextBox14.Text = "$"
        Me.TextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox15
        '
        Me.TextBox15.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox15.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox15.Location = New System.Drawing.Point(83, 99)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(26, 13)
        Me.TextBox15.TabIndex = 36
        Me.TextBox15.Text = "$"
        Me.TextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox16
        '
        Me.TextBox16.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox16.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox16.Location = New System.Drawing.Point(83, 246)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(26, 13)
        Me.TextBox16.TabIndex = 37
        Me.TextBox16.Text = "$"
        Me.TextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox17
        '
        Me.TextBox17.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox17.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox17.Location = New System.Drawing.Point(158, 61)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(21, 15)
        Me.TextBox17.TabIndex = 38
        Me.TextBox17.Text = "/hr"
        '
        'TextBox18
        '
        Me.TextBox18.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox18.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox18.Location = New System.Drawing.Point(158, 133)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(21, 15)
        Me.TextBox18.TabIndex = 39
        Me.TextBox18.Text = "/hr"
        '
        'TextBox19
        '
        Me.TextBox19.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox19.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox19.Location = New System.Drawing.Point(158, 203)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(21, 15)
        Me.TextBox19.TabIndex = 40
        Me.TextBox19.Text = "/hr"
        '
        'TextBox20
        '
        Me.TextBox20.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox20.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox20.Location = New System.Drawing.Point(158, 170)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(21, 15)
        Me.TextBox20.TabIndex = 41
        Me.TextBox20.Text = "/hr"
        '
        'TextBox21
        '
        Me.TextBox21.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox21.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox21.Location = New System.Drawing.Point(158, 99)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(21, 15)
        Me.TextBox21.TabIndex = 42
        Me.TextBox21.Text = "/hr"
        '
        'TextBox22
        '
        Me.TextBox22.BackColor = System.Drawing.SystemColors.Menu
        Me.TextBox22.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox22.Location = New System.Drawing.Point(158, 246)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(21, 15)
        Me.TextBox22.TabIndex = 43
        Me.TextBox22.Text = "/hr"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(130, 300)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(88, 29)
        Me.Button2.TabIndex = 44
        Me.Button2.Text = "Clear"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(252, 300)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(88, 29)
        Me.Button3.TabIndex = 45
        Me.Button3.Text = "Exit"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(352, 341)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TextBox22)
        Me.Controls.Add(Me.TextBox21)
        Me.Controls.Add(Me.TextBox20)
        Me.Controls.Add(Me.TextBox19)
        Me.Controls.Add(Me.TextBox18)
        Me.Controls.Add(Me.TextBox17)
        Me.Controls.Add(Me.TextBox16)
        Me.Controls.Add(Me.TextBox15)
        Me.Controls.Add(Me.TextBox14)
        Me.Controls.Add(Me.TextBox13)
        Me.Controls.Add(Me.TextBox12)
        Me.Controls.Add(Me.TextBox11)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.txtTotal6)
        Me.Controls.Add(Me.txtTotal3)
        Me.Controls.Add(Me.txtTotal4)
        Me.Controls.Add(Me.txtTotal5)
        Me.Controls.Add(Me.txtTotal2)
        Me.Controls.Add(Me.nudTwelve)
        Me.Controls.Add(Me.nudFour)
        Me.Controls.Add(Me.nudSix)
        Me.Controls.Add(Me.nudTen)
        Me.Controls.Add(Me.nudEight)
        Me.Controls.Add(Me.nudThree)
        Me.Controls.Add(Me.nudFive)
        Me.Controls.Add(Me.nudSeven)
        Me.Controls.Add(Me.nudNine)
        Me.Controls.Add(Me.nudEleven)
        Me.Controls.Add(Me.nudTwo)
        Me.Controls.Add(Me.nudOne)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Program 1"
        CType(Me.nudOne, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTwo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudEleven, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudNine, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudSeven, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudFive, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudThree, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudEight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudSix, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudFour, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudTwelve, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txtTotal As System.Windows.Forms.TextBox
    Friend WithEvents nudOne As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTwo As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudEleven As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudNine As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudSeven As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudFive As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudThree As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudEight As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTen As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudSix As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudFour As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudTwelve As System.Windows.Forms.NumericUpDown
    Friend WithEvents txtTotal2 As System.Windows.Forms.TextBox
    Friend WithEvents txtTotal5 As System.Windows.Forms.TextBox
    Friend WithEvents txtTotal4 As System.Windows.Forms.TextBox
    Friend WithEvents txtTotal3 As System.Windows.Forms.TextBox
    Friend WithEvents txtTotal6 As System.Windows.Forms.TextBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button

End Class
